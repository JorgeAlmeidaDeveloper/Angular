package com.digitalinnovation.springboots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootsApplicationTests {

	@Test
	void contextLoads() {
	}

}
